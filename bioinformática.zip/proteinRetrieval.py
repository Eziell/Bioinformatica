from Bio import SeqIO
import requests
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import uniRetrieval
OMIM="uniprot-database_(type_mim+168600).fasta"
parkinson_sequences = SeqIO.parse(open(OMIM),'fasta')
proteins=[]
all_terms=[]
#opening proteins.tsv for writting procedures.
f = open('proteins.tsv', "w")

#retrieving protein names and IDs
f.write(str("Retrieving protein names and IDs from "+ OMIM + "\n"))
f.write(str("ProteinName\tProteinID\n"))
with open(OMIM) as out_file:
    for fasta in parkinson_sequences:
        name, sequence, = fasta.id, str(fasta.seq)
        id = name.split("|")
        #retrieving gene
        f.write(str(id[2]+"\t"+id[1]+"\n"))
        proteins.append(id[1])



#GO term counting 
protein_terms = []
protein_label = []
all_terms = []
for protein_id in proteins:
        #get the annotations
        annotations = uniRetrieval.get_full_annotation(protein_id)
        protein_terms.append(annotations)
        protein_label.append(protein_id)
        all_terms.extend(annotations)

#Heatmap
f.write("By looking at the correlation plot, there is a clear divide between 2 groups of proteins\n")
corr_plot = uniRetrieval.heat_plot_analysis(protein_label, protein_terms, False)

f.writelines(["%s\n" % item for item in corr_plot])

#################################################################
term_counts = {term: all_terms.count(term) for term in all_terms}
distinct_terms = list(term_counts)


# Examine the first 10 terms of the term_counts
f.write(str("First 10 GO terms:\n"))
f.write(str("GO ID:\tTerm Counts:\tName:\n"))
for go_id in distinct_terms[:10]:
    name = uniRetrieval.get_term_info(go_id)['name']
    f.write(str(str(go_id)+ '\t'+ str(term_counts[go_id])+ '\t'+ name + '\n'))
    

# Get common GO terms
f.write(str("\nCommon GO terms ("+str(len(proteins))+" proteins):\n"))
f.write(str("GO ID:\tAspect:\tName:\n"))
for go_id in distinct_terms:
    if term_counts[go_id] == 11:
        go_info = uniRetrieval.get_term_info(go_id)
        f.write(str(go_id+ '\t'+ go_info['aspect']+ '\t'+ go_info['name'] + '\n'))
###########################

f.close()